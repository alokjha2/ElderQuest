---
title: Idiqlat - Version History
fontversion: 2.000
---

### 2025 Dec 17 (WSTech team) Idiqlat Version 2.000 (production release)
- Initial version of font (based on East Syriac Marcus)

